# E-Commerce Product Management Using Python

## Features
- Add products
- View products
- Search products
- Update products
- Delete products
- Inventory stock management
- SQLite database storage
- Product reports using pandas
- Clean table output using tabulate

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python main.py
```
