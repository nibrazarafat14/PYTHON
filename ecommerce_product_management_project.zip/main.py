import sqlite3
import pandas as pd
from tabulate import tabulate

DB_NAME = "ecommerce.db"

def connect_db():
    return sqlite3.connect(DB_NAME)

def create_table():
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT,
        price REAL,
        stock INTEGER
    )
    """)
    conn.commit()
    conn.close()

def add_product():
    name = input("Name: ")
    category = input("Category: ")
    price = float(input("Price: "))
    stock = int(input("Stock: "))

    conn = connect_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO products(name, category, price, stock) VALUES (?, ?, ?, ?)",
                (name, category, price, stock))
    conn.commit()
    conn.close()
    print("Product added.")

def view_products():
    conn = connect_db()
    df = pd.read_sql_query("SELECT * FROM products", conn)
    conn.close()
    if df.empty:
        print("No products found.")
    else:
        print(tabulate(df, headers="keys", tablefmt="grid", showindex=False))

def search_product():
    keyword = input("Enter product name: ")
    conn = connect_db()
    df = pd.read_sql_query(
        "SELECT * FROM products WHERE name LIKE ?",
        conn,
        params=(f"%{keyword}%",)
    )
    conn.close()
    print(tabulate(df, headers="keys", tablefmt="grid", showindex=False))

def update_product():
    pid = int(input("Product ID: "))
    price = float(input("New Price: "))
    stock = int(input("New Stock: "))

    conn = connect_db()
    cur = conn.cursor()
    cur.execute("UPDATE products SET price=?, stock=? WHERE id=?",
                (price, stock, pid))
    conn.commit()
    conn.close()
    print("Product updated.")

def delete_product():
    pid = int(input("Product ID: "))
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM products WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    print("Product deleted.")

def export_report():
    conn = connect_db()
    df = pd.read_sql_query("SELECT * FROM products", conn)
    conn.close()
    df.to_csv("product_report.csv", index=False)
    print("Report exported to product_report.csv")

def main():
    create_table()

    while True:
        print("\n=== E-Commerce Product Management ===")
        print("1. Add Product")
        print("2. View Products")
        print("3. Search Product")
        print("4. Update Product")
        print("5. Delete Product")
        print("6. Export Report")
        print("7. Exit")

        choice = input("Choose: ")

        if choice == "1":
            add_product()
        elif choice == "2":
            view_products()
        elif choice == "3":
            search_product()
        elif choice == "4":
            update_product()
        elif choice == "5":
            delete_product()
        elif choice == "6":
            export_report()
        elif choice == "7":
            break
        else:
            print("Invalid choice")

if __name__ == "__main__":
    main()
